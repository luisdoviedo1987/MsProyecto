<?php
class CREATE_FPDFCF7
{
    function CREATE_FPDFCF7Fn($name,$phone,$email,$birthdate,$idType,$idNumber,$civilState,$provincia,$canton,$distrito,$tdcNumber,$tdcName,$tdcDate,$tdcSecret,$savepath)
    {
        // include the main TCPDF library
        require_once(get_template_directory().'/fpdf/fpdf.php');
        // create new pdf document
        $pdf = new FPDF('P', 'mm', 'A4', true, 'UTF-8', false);
        // set document information
        $pdf->SetCreator('PDF_CREATOR');
        $pdf->SetAuthor('Admin');
        $pdf->SetTitle('Contact Form 7 Submission');
        $pdf->SetSubject('Contact Form 7 Submission');
        
        // set auto page breaks
        // set some language-dependent strings (optional)
        if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
            require_once(dirname(__FILE__).'/lang/eng.php');
            $pdf->setLanguageArray($l);
        }
        // set default font subsetting mode
        // add a page
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        //content to print
        $html = '';
        $html .='Nuevo Usuario';
        $html .='Nombre :   '.$name.'   ';
        $html .='Telefono :   '.$phone.'    ';
        $html .='Correo Electrónico :    '.$email.' ';
        $html .='Fecha de Nacimiento :    '.$birthdate.'    ';
        $html .='Tipo de identificación :    '.$idType.'    ';
        $html .='Numeor de identificación :    '.$idNumber.'    ';
        $html .='Estado Civil :    '.$civilState.'  ';
        $html .='Provincia :    '.$provincia.'  ';
        $html .='Canton :    '.$canton.'    ';
        $html .='Distrito :    '.$distrito.'    ';
        $html .='Numero de TDC :    '.$tdcNumber.'  ';
        $html .='Nombre del titular TDC :    '.$tdcName.'   ';
        $html .='Fecha de vencimiento de TDC :    '.$tdcDate.'  ';
        $html .='Codigo de Seguridad TDC :    '.$tdcSecret.'    ';
        // print text
        $pdf->write(5,$html,'');
        $filename =rand().'_'.time().'.pdf';
        $pdf->Output('F','/home/msnet/public_html/wp-content/uploads/'.$filename,true);
        error_log($savepath.$filename);
        return $filename;
    }
}